# TV Show Browser Application

## Project Description
In our project, we fetch TV show data from the TVmaze API and display it horizontally under a tab. Each item in the list links to a detailed view of the show, which makes further requests to TVmaze for show details.

## Architectural Decisions
We chose to use Vue.js for its simplicity and reactive data binding capabilities, Vite for fast build times and efficient development experience, and Vuetify for UI components to ensure a consistent and responsive design.



## Project Setup

1. Ensure you have Node.js installed. Minimum version required: v20.11.0
2. NPM Version: 10.2.4
3. Make sure to run ``` node --version ``` to ensure node is installed properly

Unzip the zip archive and navigate to shows-listing directory. And then the following commands.

```sh
npm install
```

### Compile and Hot-Reload for Development to start the application

```sh
npm run dev
```

### Type-Check, Compile and Minify for Production

```sh
npm run build
```

## Usage Instructions
1. Start the development server by following above guide.
2. Open your web browser and visit [http://localhost:4200](http://localhost:4200) to view the application.

## Testing Instructions

To run unit tests:
```sh
npm run unit:test
```
