<script setup>
import axios from 'axios'
import { useRoute, useRouter } from 'vue-router'

const route = useRoute()
const router = useRouter()
const showId = ref(route.params.id)

if (!showId.value) {
  router.push('/shows')
}

const showData = ref({
  isLoading: true,
  isError: false,
  message: '',
  data: {}
})
const isCardSummaryVisible = ref({})

const fetchShow = () => {
  showData.value.isLoading = true
  const config = {
    method: 'get',
    url: `https://api.tvmaze.com/shows/${showId.value}`,
    headers: {
      'Content-Type': 'application/json',
    },
  }

  axios.request(config)
    .then((response) => {
      showData.value.isLoading = false
      showData.value.isError = false
      showData.value.data = response.data
      isCardSummaryVisible[showData.value.id] = false;
    })
    .catch((error) => {
      showData.value.isLoading = false
      showData.value.isError = true
      showData.value.message = error.response.data.message
    })
}

onMounted(() => {
  fetchShow()
})

</script>

<template>
  <div class="text-center my-4" v-if="showData.isLoading">
    <VProgressCircular
      color="purple"
      :size="50"
      :width="6"
      indeterminate
    ></VProgressCircular>
  </div>

  <div v-else-if="showData.isError">
    <VAlert
      color="error"
      title="Request failed"
      :text="showData.message"
    ></VAlert>
  </div>

  <VRow v-else>

    <VCol
      cols="12"
      md="6"
      sm="8"
      offset-md="3"
      offset-sm="2"
    >
      <VCard>
        <VImg
          :max-height="300"
          aspect-ratio="16/9"
          cover
          :src="showData.data.image.original"
        />

        <VCardItem>
          <VCardTitle>{{ showData.data.name }}</VCardTitle>
        </VCardItem>

        <VCardItem>
          <VBtn :href="showData.data.url" target="_blank">
            TV Maze
          </VBtn>
        </VCardItem>

        <VCardText class="d-flex align-center flex-wrap">
          <span class="text-subtitle-2"><strong>Genre:</strong> {{ showData.data.genres.join(', ') }}</span>
        </VCardText>

        <VCardText class="d-flex align-center flex-wrap">
          <span class="text-subtitle-2"><strong>Status:</strong> {{ showData.data.status }}</span>
        </VCardText>

        <VCardText class="d-flex align-center flex-wrap">
          <span class="text-subtitle-2"><strong>Language:</strong> {{ showData.data.language }}</span>
        </VCardText>

        <VCardText class="d-flex align-center flex-wrap">
          <span class="text-subtitle-2"><strong>Official Site:</strong> <a target="_blank" :href="showData.data.officialSite">{{ showData.data.officialSite }}</a></span>
        </VCardText>

        <VCardText class="d-flex align-center flex-wrap">
          <span class="text-subtitle-2"><strong>Previous Episode:</strong> <a target="_blank" :href="showData.data._links.previousepisode.href">{{ showData.data._links.previousepisode.name }}</a></span>
        </VCardText>

        <VCardText class="d-flex align-center flex-wrap">
          <span class="text-subtitle-2"><strong>Watch time:</strong> {{ showData.data.runtime }} Minutes</span>
        </VCardText>

        <VCardText class="d-flex align-center flex-wrap">
          <VRating
            :model-value="showData.data.rating.average"
            length="10"
            readonly
            density="compact"
            class="me-3"
          />
          <span class="text-subtitle-2">{{ showData.data.rating.average }} Rating</span>
        </VCardText>

        <VCardActions>
          <VBtn @click="isCardSummaryVisible[showData.data.id] = !isCardSummaryVisible[showData.data.id]">
            Summary
          </VBtn>

          <VSpacer />

          <VBtn
            icon
            size="small"
            @click="isCardSummaryVisible[showData.data.id] = !isCardSummaryVisible[showData.data.id]"
          >
            <VIcon :icon="isCardSummaryVisible[showData.data.id] ? 'ri-arrow-up-s-line' : 'ri-arrow-down-s-line'" />
          </VBtn>
        </VCardActions>

        <VExpandTransition>
          <div v-show="isCardSummaryVisible[showData.data.id]">
            <VDivider />
            <VCardText v-html="showData.data.summary"></VCardText>
          </div>
        </VExpandTransition>
      </VCard>
    </VCol>

  </VRow>
</template>
