<script setup>
import axios from 'axios'
import { useRouter } from 'vue-router'

const router = useRouter();

const showsData = ref({
  isLoading: true,
  isError: false,
  message: '',
  data: [],
  filteredData: [],
})

const errors = ref({
  showName: { error: false, message: '' },
})
const showFilter = ref({
  name: '',
})


const fetchShows = () => {
  showsData.value.isLoading = true
  const config = {
    method: 'get',
    url: `https://api.tvmaze.com/shows`,
    headers: {
      'Content-Type': 'application/json',
    },
  }

  axios.request(config)
    .then((response) => {
      showsData.value.isLoading = false
      showsData.value.isError = false
      showsData.value.data = response.data
      showsData.value.filteredData = response.data
    })
    .catch((error) => {
      showsData.value.isLoading = false
      showsData.value.isError = true
      showsData.value.message = error.response.data.message
    })
}

const handleSubmit = () => {

  showsData.value.isLoading = true
  showsData.value.isSuccess = false

  if(showFilter.value.name){
    showsData.value.filteredData = showsData.value.data.filter(show => show.name.includes(showFilter.value.name))
  }else{
    showsData.value.filteredData = showsData.value.data;
  }

  if (showsData.value.filteredData.length) {
    showsData.value.isLoading = false
    showsData.value.isError = false
  } else {
    showsData.value.isLoading = false
    showsData.value.isError = true
    showsData.value.message = 'No matching record found'
  }

}

onMounted(() => {
  fetchShows()
})

</script>

<template>
  <div class="text-center my-4" v-if="showsData.isLoading">
    <VProgressCircular
      color="purple"
      :size="50"
      :width="6"
      indeterminate
    ></VProgressCircular>
  </div>

  <div v-else-if="showsData.isError">
    <VAlert
      color="error"
      title="Request failed"
      :text="showsData.message"
    ></VAlert>
  </div>

  <VRow v-else>

    <VCol
      cols="12"
    >
      <VForm @submit.prevent="handleSubmit" class="mt-2">
        <VCard class="mb-4" title="Filter Shows By Name">
          <VCardText>
            <VRow>
              <VCol
                md="6"
                cols="12"
              >
                <VTextField
                  v-model="showFilter.name"
                  placeholder="Show"
                  label="Name"
                />
                <p v-show="errors.showName.error" class="v-field--error ma-0 mt-1">
                  {{ errors.showName.message }}
                </p>
              </VCol>
              <VCol
                md="6"
                cols="12"
                class="d-flex flex-wrap gap-4"
              >
                <VBtn type="submit">Search</VBtn>
              </VCol>
            </VRow>
          </VCardText>
        </VCard>
      </VForm>
    </VCol>

    <VCol
      cols="12"
      md="4"
      sm="6"
      v-for="show in showsData.filteredData"
      :key="show.id"
    >
      <VCard>
        <VImg
          :max-height="300"
          aspect-ratio="16/9"
          cover
          :src="show.image.original"
        />

        <VCardItem>
          <VCardTitle>{{ show.name }}</VCardTitle>
        </VCardItem>

        <VCardItem>
          <VBtn class="mr-3" @click="router.push(`/show/${show.id}`)">
            Details
          </VBtn>
          <VBtn :href="show.url" target="_blank">
            TV Maze
          </VBtn>
        </VCardItem>

        <VCardText class="d-flex align-center flex-wrap">
          <span class="text-subtitle-2"><strong>Genre:</strong> {{ show.genres.join(', ') }}</span>
        </VCardText>
        <VCardText class="d-flex align-center flex-wrap">
          <span class="text-subtitle-2"><strong>Watch time:</strong> {{ show.runtime }} Minutes</span>
        </VCardText>
        <VCardText class="d-flex align-center flex-wrap">
          <VRating
            :model-value="show.rating.average"
            length="10"
            readonly
            density="compact"
            class="me-3"
          />
          <span class="text-subtitle-2">{{ show.rating.average }} Rating</span>
        </VCardText>

      </VCard>
    </VCol>

  </VRow>
</template>
