<script setup>
import Shows from '@/views/dashboard/Shows.vue';
import { useRoute } from 'vue-router';

const route = useRoute()
const activeTab = ref(route.params.tab)
const tabs = [
  {
    title: 'Shows',
    icon: 'ri-movie-2-line',
    tab: 'shows',
  },
]

</script>

<template>

  <div>
    <VTabs
      v-model="activeTab"
      show-arrows
    >
      <VTab
        v-for="item in tabs"
        :key="item.icon"
        :value="item.tab"
      >
        <VIcon
          size="20"
          start
          :icon="item.icon"
        />
        {{ item.title }}
      </VTab>
    </VTabs>

    <VWindow
      v-model="activeTab"
      class="mt-5 disable-tab-transition"
      :touch="false"
    >

      <VWindowItem value="shows">
        <Shows />
      </VWindowItem>

    </VWindow>
  </div>
</template>
