<script setup>
import Show from '@/views/dashboard/Show.vue';
</script>

<template>
  <div>
    <Show />
  </div>
</template>
