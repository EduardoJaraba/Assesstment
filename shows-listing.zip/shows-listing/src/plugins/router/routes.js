export const routes = [
  { path: '/', redirect: '/shows' },
  {
    path: '/',
    component: () => import('@/layouts/default.vue'),
    children: [
      {
        path: 'shows',
        component: () => import('@/pages/shows.vue'),
      },
      {
        path: 'show/:id',
        component: () => import('@/pages/show.vue'),
      },
    ],
  },
  {
    path: '/',
    component: () => import('@/layouts/blank.vue'),
    children: [
      {
        path: '/:pathMatch(.*)*',
        component: () => import('@/pages/error.vue'),
      },
    ],
  },
]
