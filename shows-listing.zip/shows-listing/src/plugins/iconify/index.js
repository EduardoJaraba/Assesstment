import './icons.css';
export default function () {
    // This plugin just requires icons import
}
