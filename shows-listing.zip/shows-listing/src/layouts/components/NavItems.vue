<script setup>
import VerticalNavLink from '@layouts/components/VerticalNavLink.vue'
</script>

<template>
  <VerticalNavLink
    :item="{
      title: 'Shows',
      to: '/',
      icon: 'ri-home-smile-line'
    }"
  />

</template>
