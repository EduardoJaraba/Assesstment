import { describe, it, expect, beforeEach } from 'vitest'
import Shows from '../src/views/dashboard/Shows.vue'
import { mount } from '@vue/test-utils'
import { createVuetify } from 'vuetify'
import * as components from 'vuetify/components'
import * as directives from 'vuetify/directives'

global.ResizeObserver = require('resize-observer-polyfill')

const vuetify = createVuetify({
  components,
  directives,
})

describe('Shows.vue', () => {
  let wrapper
  beforeEach(() => {
    wrapper = mount(Shows, {
      props: {},
      global: {
        plugins: [vuetify],
      },
    })
  })

  it('displays error message when request fails', async () => {
    wrapper.vm.showsData.isLoading = false
    wrapper.vm.showsData.isError = true
    wrapper.vm.showsData.message = 'Error fetching data'
    await wrapper.vm.$nextTick()
    expect(wrapper.html()).to.include('Error fetching data')
  })

  it('filters shows by name correctly', async () => {
    const mockShows = [
      { id: 1, name: 'Show A', genres: [], rating: { average: 0 }, runtime: 0, image: { original: '' } },
      { id: 2, name: 'Show B', genres: [], rating: { average: 0 }, runtime: 0, image: { original: '' } },
    ]
    wrapper.vm.showsData.data = mockShows
    wrapper.vm.showFilter.name = 'Show A'
    wrapper.vm.handleSubmit()
    await wrapper.vm.$nextTick()
    expect(wrapper.vm.showsData.filteredData).to.deep.equal([mockShows[0]])
  })
})

